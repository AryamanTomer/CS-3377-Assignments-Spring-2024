#!/usr/bin/python
input = raw_input('Please enter a number:')
if(input == '1'):
	print('You entered one.')
elif(input == '2'):
	print('You entered two.')
elif(input == '3'):
	print('You entered three.')
else:
	print('You entered a big number...')
print('End of program.')

