#include <stdio.h>
#include <stdlib.h>   
int main()
{
	printf("Hello World\n");   // waw hello Richard and ok
 	exit(0);         // end of the program
}