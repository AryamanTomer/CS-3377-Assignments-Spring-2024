#!/usr/bin/python
my_in = raw_input('Enter your name:')
if(my_in != ''):
	print('Thank you, ' + my_in)
else:
	print('Program requires input to continue.')
	exit()
print('Program running with your input.')

