#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <ctype.h>

#define MAX_COMMAND_LENGTH 100
#define MAX_ARGUMENTS 10

void process_exit();
void execute_command(char *command);
void process_redirection(char *command);
void process_semicolon(char *commmands);
char *trim(char *str);

void process_exit(){
	printf("Exiting the shell.\n");
	exit(0);
}

void execute_command(char *command) {
	char *args[MAX_ARGUMENTS];
	int arg_count = 0;

	char *token = strtok(command, " ");
	while(token != NULL){
		args[arg_count++] = token;
		token = strtok(NULL, " ");
	}
	args[arg_count] = NULL;

	pid_t pid = fork();

	if(pid == 0){
		execvp(args[0], args);
		perror("Execution failed");
		exit(1);
	} else if (pid > 0) {
		wait(NULL);
	} else {
		perror("Fork failed");
		exit(1);
	}
}

void process_redirection(char *command){
	char *token = strtok(command, ">");
	char *cmd = strtok(NULL, ">");

	if(cmd != NULL){
		FILE *file = fopen(trim(cmd), "w");
		if(file == NULL) {
			perror("Error opening file");
			exit(1);
		}
		int fd = dup(fileno(stdout));
		dup2(fileno(file), fileno(stdout));

		execute_command(trim(token));
		fflush(stdout);
		dup2(fd, fileno(stdout));
		close(fd);
		fclose(file);
	} else {
	printf("Invalid command for redirection.\n");
	}
}

void process_semicolon(char *commands) {
	char *token = strtok(commands, ";");
	while(token != NULL){
	execute_command(trim(token));
	token = strtok(NULL, ";");
	}
}

char *trim(char *str) {
	while(isspace((unsigned char)*str))
		str++;
	
	if(*str == 0)
		return str;

	char *end = str + strlen(str) - 1;
	while(end > str && isspace((unsigned char)*end))
		end--;
	
	end[1] = '\0';

	return str;
}

int main() {
	char input[MAX_COMMAND_LENGTH];

	while(1) {
	printf("Enter a command: ");
	fgets(input, sizeof(input), stdin);

	input[strcspn(input, "\n")] = '\0';

	if(strcmp(input, "exit") == 0) {
		process_exit();
	} else if (strstr(input, ">") != NULL) {
		process_redirection(input);
	} else if (strstr(input, ";") != NULL) {
		process_semicolon(input);
	} else {
		execute_command(input);
	}
	}

	return 0;
}
