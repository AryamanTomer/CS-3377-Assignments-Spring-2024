#!/bin/bash
# This is a shell script that displays the date, home directory, and path

echo "Current date and time: $(date)"
echo "Home directory: $HOME"
echo "PATH variable: $PATH"

