#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <arpa/inet.h> 


int main(int argc, char *argv[])
{
    if(argc != 3) {
      printf("Please enter the correct number of arguments!\n");
      return 1;
    }
    char *ip = argv[1];
    int port = atoi(argv[2]);

    int sockfd = 0, n = 0;
    char recvBuff[1024];
    struct sockaddr_in serv_addr; 


    memset(recvBuff, '0',sizeof(recvBuff));
    if((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        printf("\n Error : Could not create socket \n");
        return 1;
    } 
    memset(&serv_addr, '0', sizeof(serv_addr)); 

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(port); 
    printf("\n Connecting...\n\n");
    printf("** the client is to connect to the server of IP [%s] and Port# [%d]\n", ip, port);
    system("date; hostname; whoami; ps ; ls -l "); 

    if(inet_pton(AF_INET, ip, &serv_addr.sin_addr)<=0)
    {
        printf("\n inet_pton error occured\n");
        return 1;
    } 
    if( connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)
    {
       printf("\n Connection Failed! \n");
       return 1;
    }
        printf("\n Connection Success! \n\n");
        system(" netstat -aont | grep \":37419 \" ");
        printf("\n\n");

    while ( (n = read(sockfd, recvBuff, sizeof(recvBuff)-1)) > 0)
    {
        printf("Reading the Messsage from the Server\n");
        recvBuff[n] = 0;
        if(fputs(recvBuff, stdout) == EOF)
        {
            printf("\n Error : Fputs error\n");
        }
    } 

    if(n < 0)
    {
        printf("\n Read error \n");
        exit(0);
    } 
    
    printf("** the client will be terminated\n\n");
    system("date; hostname; whoami; ps ; ls -l ");
    printf("\n** the client ends\n\n");
    
    return 0;
}
