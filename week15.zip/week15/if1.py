#!/usr/bin/python
my_in = raw_input('Enter your name: ')
if(my_in != ''):
	print('Thank you,' + my_in)
print('Program running, with or without your input.')

