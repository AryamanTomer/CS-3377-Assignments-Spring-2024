#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <time.h> 
#include <signal.h>



  
int main(int argc, char *argv[])
{
    if(argc != 3) {
       printf("Usage: %s <port> <time>\n", argv[0]);
       return 1;
    }
    int port = atoi(argv[1]);
    int alarm_duration = atoi(argv[2]);
    int alarm_reset = 30;
    
    int listenfd = 0, connfd = 0;
    struct sockaddr_in serv_addr;
    
    char sendBuff[1025];
    time_t ticks; 
    listenfd = socket(AF_INET, SOCK_STREAM, 0);
    memset(&serv_addr, '0', sizeof(serv_addr));
    memset(sendBuff, '0', sizeof(sendBuff)); 
    
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    serv_addr.sin_port = htons(port); 
    
    bind(listenfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)); 
    signal(SIGALRM, exit);
    alarm(alarm_duration);
    printf("\n This server is currently listening....\n");
    printf("** the server uses port# [%d] to listen with [%d] for alarm **\n", port, alarm_duration);
    printf("** the server will be terminated after [%d] seconds of inactivity **\n\n", alarm_duration);
    system("date; hostname; whoami; ps ; ls -l "); 
    printf("\n");
    listen(listenfd, 10);
    while(1)
    {
        connfd = accept(listenfd, (struct sockaddr*)NULL, NULL);
        alarm(0);
        printf("\n This server has a successful connection\n\n");
        system(" netstat -aont | grep \" `hostname -i`:3741[0-9] \" ");
        alarm(alarm_reset);
        if(alarm_duration == 0) {
            printf("This server is terminating\n");
            printf("** the server ends **\n");
            system("date; hostname; whoami; ps ; ls -l ");
            printf("\n");
            exit(0);
        }
        else if(alarm_duration > 0) {
            printf("---Alarm reset for %d seconds---\n", alarm_reset);
            if(alarm_duration == 10) {
                printf("\n** Running Test Case #1: \n\n");
                if(alarm_duration == 0) {
                    printf("This Alarm is now expired...\n");
                    printf("** the server ends **\n");
                    system("date; hostname; whoami; ps ; ls -l ");
                    printf("\n");
                    exit(0);
                }
            }
            else if(alarm_duration == 120) {
                printf("\n** Running Test Case #2: \n\n");      
                ticks = time(NULL);
                snprintf(sendBuff, sizeof(sendBuff), "%.24s\r\n", ctime(&ticks));
                write(connfd, sendBuff, strlen(sendBuff)); 
                printf("** the server ends **\n");
                system("date; hostname; whoami; ps ; ls -l ");
                printf("\n");
                close(connfd);
                sleep(1);
                exit(0);
            }
            else if(alarm_duration == 30) {
                printf("\n** Running Test Case #3: \n\n");     
                ticks = time(NULL);
                snprintf(sendBuff, sizeof(sendBuff), "%.24s\r\n", ctime(&ticks));
                write(connfd, sendBuff, strlen(sendBuff)); 
                close(connfd);
                sleep(1);
                printf("\nThis is a success\n\n");
                printf("\n---Remaining time: %d seconds---\n\n", alarm_duration);
                if(alarm_duration == 0) {
                    printf("This alarm has expired...\n");
                    printf("** the server ends **\n");
                    system("date; hostname; whoami; ps ; ls -l ");
                    printf("\n");
                    exit(0);
                }
            } 
            else if(alarm_duration == 0) {
                printf("This server is terminating...\n");
                printf("** the server ends **\n");
                system("date; hostname; whoami; ps ; ls -l ");
                printf("\n");
                exit(0);
            }
        }
        
        else {
       	    printf("This is not a valid duration.\n");
    				exit(0);
        }
    }
    return 0;
}
