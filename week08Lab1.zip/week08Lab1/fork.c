#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
void printHeader(){
	printf("Name: Aryaman Tomer\n");
	printf("NetID: axt210052\n");
	printf("Course/Section: CS 3377.003\n");
	printf("Week#: 8\n");
	printf("Lab#: 1\n");
	printf("\n");

	system("date; whoami; ps; ls -l ");
}

int main(int argc, char *argv[]){
	if(argc != 2) {
		fprintf(stderr, "Usage: %s <case_number>\n", argv[0]);
		exit(EXIT_FAILURE);
	}

	int caseN = atoi(argv[1]);
	printf("\n\n");

	printHeader();

	switch (caseN) {
		case 1:
			fork();
			printf("\n\nCase %d - pid=%d\n", caseN, getpid());
			break;
		case 2:
			fork();
			fork();
			printf("\n\nCase %d - pid=%d\n", caseN, getpid());
			break;
		case 3:
			if ( fork()) {
				fork();
			}
			printf("\n\nCase %d - pid=%d\n", caseN, getpid());
			break;
		case 4:
			if ( fork() &&  fork()) {
				fork();
			}
			printf("\n\nCase %d - pid=%d\n", caseN, getpid());
			break;
		case 5:
			
			for(int i = 1; i < 4; i++){
				fork();
			}
			printf("\n\nCase %d - pid=%d\n", caseN, getpid());
			break;
		default:
			fprintf(stderr, "Invalid case number. Choose from 1 to 5.\n" );
			exit(EXIT_FAILURE);
	}
	return 0;
}
