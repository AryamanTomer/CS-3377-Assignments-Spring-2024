/* This still very simple ls with lstat and stat calls
   for the file information in a directory.

 */

#include <sys/types.h>
#include <sys/stat.h>

#include <dirent.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

void printFileType(mode_t mode){
       	if (S_ISREG(mode))
	        printf("regular file");
        else if (S_ISDIR(mode))
	        printf("directory");
        else if (S_ISCHR(mode))
	        printf("character special");
        else if (S_ISBLK(mode))
	        printf("block special");					       else if (S_ISFIFO(mode))  
		printf("FIFO");
        else if (S_ISLNK(mode))
	        printf("symbolic link");
        else if (S_ISSOCK(mode))
	        printf("socket");
        else
	        printf("unknown");

}

int
main(int argc, char **argv) {

	DIR *dp;
	struct dirent *dirp;

	if (argc != 2) {
		fprintf(stderr, "usage: %s dir_name\n", argv[0]);
		exit(EXIT_FAILURE);
	}

	if ((dp = opendir(argv[1])) == NULL ) {
		fprintf(stderr, "can't open '%s': %s\n", argv[1], strerror(errno));
		exit(EXIT_FAILURE);
	}

	if (chdir(argv[1]) == -1) {
		fprintf(stderr, "can't chdir to '%s': %s\n", argv[1], strerror(errno));
		exit(EXIT_FAILURE);
	}

	int regCount = 0, dirCount = 0, chrCount = 0, blkCount = 0, fifoCount = 0, lnkCount = 0, sockCount = 0, unknownCount = 0;
	while ((dirp = readdir(dp)) != NULL ) {
		struct stat sb;
		if (stat(dirp->d_name, &sb) == -1) {
			fprintf(stderr, "Can't stat %s: %s\n", dirp->d_name,
						strerror(errno));

			if (lstat(dirp->d_name, &sb) == -1) {
				fprintf(stderr,"Can't stat %s: %s\n", dirp->d_name,
						strerror(errno));
				continue;
			}
		}

		if (S_ISREG(sb.st_mode))
		           regCount++;
		 else if (S_ISDIR(sb.st_mode))
			   dirCount++;
		 else if (S_ISCHR(sb.st_mode))
			   chrCount++;
		 else if (S_ISBLK(sb.st_mode))								   blkCount++;
		 else if (S_ISFIFO(sb.st_mode))
			    fifoCount++;
		 else if (S_ISLNK(sb.st_mode))
			    lnkCount++;
		 else if (S_ISSOCK(sb.st_mode))
			    sockCount++;
		 else
			     unknownCount++;


		printf("%s: ", dirp->d_name);
		printFileType(sb.st_mode);
		printf(" -- with stat\n");

		if (lstat(dirp->d_name, &sb) == -1) {
			fprintf(stderr,"not for stat %s: %s\n", dirp->d_name,
						strerror(errno));
			continue;
		}

		printf("%s: ", dirp->d_name);
		printFileType(sb.st_mode);
		printf(" -- with lstat\n\n");
	}
 int totalCount = regCount + dirCount + chrCount + blkCount + fifoCount + lnkCount + sockCount + unknownCount;
     printf("total count for regular file: %d (which is %.2f%% of total count)\n", regCount, (regCount * 100.0 / totalCount));
         printf("total count for directory: %d (which is %.2f%% of total count)\n", dirCount, (dirCount * 100.0 / totalCount));

	 printf("total count of the directory entries processed: %d (which is 100%%)\n", totalCount);
	closedir(dp);
	exit(EXIT_SUCCESS);
}
