#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_COMMAND_LENGTH 100

int main(){
	char command[MAX_COMMAND_LENGTH];

	while(1){
	printf("Enter a command: ");
	fgets(command, MAX_COMMAND_LENGTH, stdin);

	command[strcspn(command, "\n")] = '\0';


	if(strcmp(command, "exit") == 0){
		printf("Exiting the program.\n");
		break;
	} else if (strcmp(command, "listall") == 0){
		strcpy(command, "ls -la");
	} else if (strcmp(command, "showme") == 0){
		char netid[] = "axt";
		snprintf(command, MAX_COMMAND_LENGTH, "w | grep %s, netid");
	} else {
		system(command);
	}
	}
	return 0;
}
