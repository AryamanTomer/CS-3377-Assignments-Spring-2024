#!/usr/bin/python
try:
	f = open('/home/max/test_file','r')
except IOError:
	print "Cannot open file."
	exit()
print "Processing file."

