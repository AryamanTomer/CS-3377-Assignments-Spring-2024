#!/user/bin/local/python
print('Good morning')